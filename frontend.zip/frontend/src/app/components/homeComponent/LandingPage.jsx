"use client"
import React, { useRef } from 'react'



const LandingPage = () => {



    return (
        <div className='landing-page-container' >
            <div className='landing-page-heading'>
                <h1>SIMPLIFYING SUCCESS</h1>
            </div>
        </div>
    )
}

export default LandingPage